package com.example.bkcalc;

import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

import static java.lang.Thread.sleep;

/*
ival = tExpressionView.getText().length();

                if(ival > 0)
                {
                    CharSequence cSeq = tExpressionView.getText().toString();
                    tExpressionView.setText(cSeq.subSequence(0, ival-1));
                }
                else
                {
                    dVal1 = Double.NaN;
                    dVal2 = Double.NaN;
                    tExpressionView.setText("");
                    tResultView.setText("");
                }
*/
// 'com.faendir.rhino:rhino-android:1.5.2'
public class MainActivity extends AppCompatActivity {

    //create Buttons, TextViews variables
    Button btnZero, btnOne, btnTwo, btnThree, btnFour, btnFive, btnSix, btnSeven, btnEight, btnNine;
    Button btnAdd, btnSub, btnDiv, btnMult, btnEqual, btnDot, btnBrackets, btnClear, btnPercent, btnBack;
    TextView resultText,  inputText, textFlow;
    String doTask;
    int iRemove = 0;
    String strZero = "0";
    boolean chkBrackets = false;
    MediaPlayer mp;


    @Override
    //onCreate method works line main function of c,c++,java
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //get ids of all xml files
        getIds();


        btnZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);//sp size in pixel
                }
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "0");
                iTell(0);
            }
        });


        btnOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "1");
                iTell(1);
            }
        });

        btnTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "2");     //str append
                iTell(2);
            }
        });

        btnThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "3");     //str append
                iTell(3);
            }
        });

        btnFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "4");     //str append
                iTell(4);
            }
        });

        btnFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "5");     //str append
                iTell(5);
            }
        });

        btnSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "6");     //str append
                iTell(6);
            }
        });

        btnSeven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }

                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "7");     //str append
                iTell(7);
            }
        });

        btnEight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "8");     //str append
                iTell(8);
            }
        });

        btnNine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 19)
                {
                    inputText.setTextSize(25);
                }
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "9");     //str append
                iTell(9);
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "+");     //str append
                cTell('+');
            }
        });


        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "-");     //str append
                cTell('-');
            }
        });

        btnMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "×");     //str append
                cTell('*');
            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "÷");     //str append
                cTell('/');
            }
        });

        btnPercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString();
                inputText.setText(doTask+ "%");     //str append
                cTell('%');

            }
        });

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            doTask = inputText.getText().toString();
                            //          used   Replaced
            doTask = doTask.replaceAll("×",   "*");
            doTask = doTask.replaceAll("%",   "%");
            doTask = doTask.replaceAll("÷",   "/");
            doTask = doTask.replaceAll("-",   "-");


            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            String finalResult = "";
                try
                {
                    Scriptable script = context.initStandardObjects();
                    finalResult = context.evaluateString(script, doTask, "javascript", 1, null).toString();
                }
                catch (Exception e)
                {
                    finalResult = "0";
                }

                //swapping input/output text showing location
                inputText.setText(finalResult);
                resultText.setText(doTask);  //doTask contains input text
                cTell('=');
                /*
                try {
                    tellResult(finalResult);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                 */
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                inputText.setText("");;
                resultText.setText("");
                cTell('#');  //all clear

            }
        });

        btnBrackets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(chkBrackets)
                {
                    doTask = inputText.getText().toString();
                    inputText.setText(doTask+ ")");
                    cTell('(');
                    chkBrackets = false;
                }
                else
                {
                    doTask = inputText.getText().toString();
                    inputText.setText(doTask+ "(");
                    cTell('(');
                    chkBrackets = true;
                }
            }
        });

        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doTask = inputText.getText().toString(); //get old string
                inputText.setText(doTask+ ".");         //append with . dot
                cTell('.');
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(inputText.length() > 0) {
                    cTell('<');
                    iRemove = inputText.getText().length();
                    if (iRemove > 0) {
                        CharSequence cSeq = inputText.getText().toString();
                        inputText.setText(cSeq.subSequence(0, iRemove - 1));
                    }
                }
            }
        });
    }



    /*
    //function to tell result
    private void tellResult(String ResultString) throws InterruptedException {
        char crr[] = ResultString.toCharArray();
        Toast.makeText(getApplicationContext(), ResultString, Toast.LENGTH_SHORT).show();
        char ch = '\0';

        cTell('=');

        for(int i = 0; i < crr.length; i++)
        {
            sleep(500);
           if(crr[i] >= '0' && crr[i] <= '9')
           {
               //function call befor that convert char to int
               iTell(Character.getNumericValue(crr[i]));
           }

           cTell(crr[i]);

        }
    }*/

    private  void getIds()
    {
        //get ids of digits buttons
        btnZero = (Button)findViewById(R.id.btn0);
        btnOne = (Button)findViewById(R.id.btn1);
        btnTwo = (Button)findViewById(R.id.btn2);
        btnThree = (Button)findViewById(R.id.btn3);
        btnFour = (Button)findViewById(R.id.btn4);
        btnFive = (Button)findViewById(R.id.btn5);
        btnSix = (Button)findViewById(R.id.btn6);
        btnSeven = (Button)findViewById(R.id.btn7);
        btnEight = (Button)findViewById(R.id.btn8);
        btnNine = (Button)findViewById(R.id.btn9);

        //gets ids of operators
        btnAdd = (Button)findViewById(R.id.btnAddition);
        btnSub = (Button)findViewById(R.id.btnSubtraction);
        btnMult = (Button)findViewById(R.id.btnMultiplication);
        btnDiv = (Button)findViewById(R.id.btnDivision);
        btnClear = (Button)findViewById(R.id.btnClear);
        btnDot = (Button)findViewById(R.id.btnDot);
        btnBrackets = (Button)findViewById(R.id.btnBrackets);
        btnPercent = (Button)findViewById(R.id.btnPercentage);
        btnEqual = (Button)findViewById(R.id.btnEquals);
        btnBack = (Button)findViewById(R.id.btnSingleCut);

        //gets ids of TextViews
        inputText = (TextView)findViewById(R.id.input_TextView);
        resultText = (TextView)findViewById(R.id.output_TextView);

    }

    private void iTell(int iPlay)
    {
        switch (iPlay)
        {
            case 0:
                mp = MediaPlayer.create(this, R.raw.zzero);
                mp.start();
                break;

            case 1:
                mp = MediaPlayer.create(this, R.raw.one);
                mp.start();
                break;
            case 2:
                mp = MediaPlayer.create(this, R.raw.two);
                mp.start();
                break;

            case 3:
                mp = MediaPlayer.create(this, R.raw.three);
                mp.start();
                break;

            case 4:
                mp = MediaPlayer.create(this, R.raw.four);
                mp.start();
                break;

            case 5:
                mp = MediaPlayer.create(this, R.raw.five);
                mp.start();
                break;

            case 6:
                mp = MediaPlayer.create(this, R.raw.six);
                mp.start();
                break;

            case 7:
                mp = MediaPlayer.create(this, R.raw.seven);
                mp.start();
                break;

            case 8:
                mp = MediaPlayer.create(this, R.raw.eight);
                mp.start();
                break;

            case 9:
                mp = MediaPlayer.create(this, R.raw.nine);
                mp.start();
                break;
        }
    }

    private void cTell(char letter)
    {
        switch (letter)
        {
            case '+':
                mp = MediaPlayer.create(this, R.raw.plus);
                mp.start();
                break;

            case '-':
                mp = MediaPlayer.create(this, R.raw.minus);
                mp.start();
                break;

            case '*':
                mp = MediaPlayer.create(this, R.raw.multiply);
                mp.start();
                break;

            case '/':
                mp = MediaPlayer.create(this, R.raw.divide);
                mp.start();
                break;

            case  '.':
                mp = MediaPlayer.create(this, R.raw.point);
                mp.start();
                break;

            case '=':
                mp = MediaPlayer.create(this, R.raw.result_is);
                mp.start();
                break;

            case '%':
                mp = MediaPlayer.create(this, R.raw.percentage);
                mp.start();
                break;

            case '(':
                mp = MediaPlayer.create(this, R.raw.brackets);
                mp.start();
                break;

            case '<': //for removing single letter
                mp = MediaPlayer.create(this, R.raw.back);
                mp.start();
                break;

            case '#':  //for all clear
                mp = MediaPlayer.create(this, R.raw.all_clear);
                mp.start();
                break;
        }
    }
}

//÷ % × −  +  =
